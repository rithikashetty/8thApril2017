package com.capgemini.appl.dao;


import java.sql.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.appl.dto.Application;
import com.capgemini.appl.dto.Location;
import com.capgemini.appl.dto.ProgramsOffered;
import com.capgemini.appl.dto.ProgramsScheduled;
import com.capgemini.appl.dto.Users;
import com.capgemini.appl.exception.UniversityAdmissionException;


@Repository("universityDao")
public class UniversityDaoImpl implements UniversityDao {
	
	
	@PersistenceContext
	private EntityManager manager;

	@Override
	public List<Application> showApplications()
			throws UniversityAdmissionException {
		Query query = manager.createNamedQuery("qryAllAppl", Application.class);
	//	Query query = manager.createQuery("select e from Application e"); //("select e from APPLICATION e", Application.class);
	
		return query.getResultList();	}

	@Override
	public boolean addProgram(ProgramsOffered p)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<ProgramsOffered> showProgramsOffereds()
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean acceptOrRejectApplication(Application application)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteProgram(String ProgramName)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateProgram(ProgramsOffered p)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Users getUserDetail(String userName)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ProgramsScheduled> getAllProgramSheduled()
			throws UniversityAdmissionException {
		try {
			TypedQuery<ProgramsScheduled> qry=manager.createNamedQuery("qryAllPrgrmScheduled",ProgramsScheduled.class);
			List<ProgramsScheduled> prgmScheduledList =qry.getResultList();
			return prgmScheduledList;
		} catch (Exception e) {
			throw new UniversityAdmissionException("Improper qry Fabrication",e);
			
		}
	
	}

	@Override
	public List<Application> getApplicationOnSheduledId(int ScheduleId)
			throws UniversityAdmissionException {
		System.out.println("in DaoImpl  getApplicationOnSheduledId");
		try {
			TypedQuery<Application> qry=manager.createNamedQuery("qryAllAppDetail",Application.class);
			qry.setParameter("prgrmId", ScheduleId);
			qry.setParameter("sts","accepted");
			List<Application> applicationList =qry.getResultList();
			System.out.println("In DaoImpl getApplicationOnSheduledId applicationList:"+applicationList);
			return applicationList;
			
		
		} catch (Exception e) {
			throw new UniversityAdmissionException("Improper qry Fabrication",e);
		}
	}

	@Override
	public boolean updateApplicationDB(int id, String status)
			throws UniversityAdmissionException {
		System.out.println("in dao Impl updateApplicationDB" );
		System.out.println("Id (DaoImplUpdateapplicationDb):"+id);
		System.out.println("Status (DaoImplUpdateapplicationDb):"+status);
		Application app = new Application();
		app.setApplicationId(id);
		app.setStatus(status);
		System.out.println("in Dao Impl:"+app);
		manager.merge(app);
		return true;
	}

	@Override
	public List<ProgramsOffered> getAllProgramDetails()
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String insertLocationDetails(Location loc)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean insertScheduledDetails(ProgramsScheduled schedule)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteSchedule(String id)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Application> showApplicantInfo(int id)
			throws UniversityAdmissionException {
		try {
			System.out.println("in showApplicantInfo");
			TypedQuery<Application> qry =manager.createNamedQuery("qryAllApplId",Application.class);
			qry.setParameter("prgrmId",id);
			List<Application> applicationList =qry.getResultList();
			System.out.println("AppList"+applicationList);
			return applicationList;
		} catch (Exception e) {
			throw new UniversityAdmissionException("Improper qry Fabrication",e);
			//e.printStackTrace();
		}
	}

	@Override
	public int getApplicationId() throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<ProgramsOffered> showAll() throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int addApplicant(Application appl)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Application showStatus(int application_id)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}



	@Override
	public int getProgramId(String programName)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<ProgramsScheduled> getAllProgramSheduled(String programName)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String isUserAuthanticate(String userName, String password)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ProgramsScheduled> showProgramInfo(Date startdate, Date enddate)
			throws UniversityAdmissionException {
		// TODO Auto-generated method stub
		return null;
	}



}
