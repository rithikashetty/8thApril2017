package com.capgemini.appl.dto;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity(name = "location")
@Table(name = "LOCATION")
@SequenceGenerator(name = "location_generate", sequenceName = "LOCATION_ID", allocationSize = 1, initialValue = 101)
public class Location {
	String locationId;
	String city;
	String hState;
	String zip;
	ProgramsScheduled ProgramsScheduled;

	@OneToOne(mappedBy = "location")
	public ProgramsScheduled getProgramsScheduled() {
		return ProgramsScheduled;
	}

	public void setProgramsScheduled(ProgramsScheduled programsScheduled) {
		ProgramsScheduled = programsScheduled;
	}

	@Id
	@Column(name = "LOCATIONID")
	@GeneratedValue(generator = "location_generate", strategy = GenerationType.SEQUENCE)
	public String getLocationId() {
		return locationId;
	}

	public void setLocationId(String locationId) {
		this.locationId = locationId;
	}

	@Column(name = "CITY")
	@NotNull(message = "City is required.")
	@Size(min = 1, max = 10, message = "City must be of size 1 to 10.")
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Column(name = "HSTATE")
	@NotNull(message = "State is required.")
	@Size(min = 1, max = 10, message = "State must be of size 1 to 10.")
	public String gethState() {
		return hState;
	}

	public void sethState(String hState) {
		this.hState = hState;
	}

	@Column(name = "ZIP")
	@NotNull(message = "Zip is required.")
	@Size(min = 6, max = 10, message = "Zip must be of size 6 to 10.")
	public String getZip() {
		return zip;
	}

	public void setZip(String zip) {
		this.zip = zip;
	}

	@Override
	public String toString() {
		return "Location [locationId=" + locationId + ", city=" + city
				+ ", hState=" + hState + ", zip=" + zip + "]";
	}


}
