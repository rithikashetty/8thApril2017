/*********************************************************************
 * File                 : EmpCrudController.java
 * Author Name          : NIKHIL PANDEY
 * Desc                 : JAVA Controller
 * Version              : 1.0
 * Creation Date        : 31-Mar-2017
 * Last Modified Date   : 31-Mar-2017
 *********************************************************************/
package com.capgemini.appl.controlers;

import java.util.ArrayList;


import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.capgemini.appl.dto.Application;
import com.capgemini.appl.dto.ProgramsScheduled;
import com.capgemini.appl.exception.UniversityAdmissionException;
import com.capgemini.appl.service.UniversityService;



import sun.util.logging.resources.logging;


@Controller
public class UniversityCrudController {
	private UniversityService service;
	List<String> designation;

	
	@Resource(name = "universityService")
	public void setEmpServices(UniversityService service) {
		this.service = service;
	}

	//Default Page of Project
	@RequestMapping("index")
	public ModelAndView welcome() {
		ModelAndView model=new ModelAndView("index");
		return model;

	}		
	////////////////////////////////////////////////////////
	@RequestMapping("applicant")
	public ModelAndView applicant() {
		ModelAndView model=new ModelAndView("applicant");
		return model;
	}

	
	@RequestMapping("showApplicant")
	public ModelAndView showApplicant() {
		ModelAndView modelAndView=null;		try {
			List<Application> list=service.showApplications();
			System.out.println(service.showApplications());
			modelAndView=new ModelAndView("error");
			modelAndView.addObject("msg", list);
		} catch (UniversityAdmissionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return modelAndView;
	}
	
	
	@RequestMapping("showAddProgram")
	public ModelAndView showaddProgram() {
		ModelAndView modelAndView=new ModelAndView("addProgram");	
		return modelAndView;
	}
	////////////////////////////rithika//////////////////
	@RequestMapping("/showProgramScheduled.do")
	public ModelAndView listAllPrgrmsScheduled(){
		
		System.out.println("In listAllPrgrmsScheduled");
		ModelAndView model =null;
		
		try {
			List<ProgramsScheduled> prgmScheduled = service.getAllProgramSheduled();
			System.out.println("Controller"+prgmScheduled);
			if(prgmScheduled.isEmpty()){
				
				model=new ModelAndView("errorAdmin");
				model.addObject("msg","No ProgramScheduledList");
				
			}
			
			else{
			model =  new ModelAndView("candidateReport");
				
			model.addObject("data",prgmScheduled);
			}
		} catch (Exception e) {
			model=new ModelAndView("errorAdmin");
			model.addObject("msg","No Applicants for this ScheduledProgramId");
		}
		
		return model;
	}
	
	@RequestMapping("/statusReport.do")
	public ModelAndView viewApplicantList(@RequestParam("id") int sProgramId){
		
		System.out.println("In Controller viewApplicantList"+sProgramId);
		ModelAndView model =null;
		
		try {
			List<Application> applicationList = service.showApplicantInfo(sProgramId);
			System.out.println("In Controller viewApplicantList"+applicationList);
			if(applicationList.isEmpty()){
				
				model=new ModelAndView("errorAdmin");
				model.addObject("msg","No Applicants for this ScheduledProgramId");
				
			}else{
			model =  new ModelAndView("candidateInfo");
			model.addObject("applicantinfo",applicationList);
			}
			
		} catch (UniversityAdmissionException e) {
			model=new ModelAndView("errorAdmin");
			model.addObject("msg","No Applicants for this ScheduledProgramId");
			e.printStackTrace();
		}
		
		return model;
		
		
	}
	@RequestMapping("/takeInterview.do")
	
	public ModelAndView takeInterview(){
		
		System.out.println("In ControllertakeInterview()");
		ModelAndView model =null;
		
		try {
			List<ProgramsScheduled> pScheduleList = service.getAllProgramSheduled();
			System.out.println("In Controller takeInterview"+pScheduleList);
			model=new ModelAndView("showSheduleDetail");
			model.addObject("data", pScheduleList);
			
		} catch (UniversityAdmissionException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return model;
	}
	
	@RequestMapping("/retriveApplication.do")
	public ModelAndView retriveApplication(@RequestParam("id") int appId){
		System.out.println("In ControllerretriveApplication:"+appId);
		ModelAndView model =null;
		try {
			List<Application> applicationList = service.getApplicationOnSheduledId(appId);
				if(applicationList.isEmpty()){
				
				model=new ModelAndView("errorMember");
				model.addObject("msg","No accepted Applicant");
				
			}else{
			model =  new ModelAndView("showAllApplicantsDetail");
			model.addObject("data",applicationList);
			}
			
		} catch (UniversityAdmissionException e) {
			model=new ModelAndView("errorMember");
			model.addObject("msg","No accepted Applicant");
			e.printStackTrace();
		}
		return model;
	}
	
	@RequestMapping("/confirmed.do")
	public ModelAndView updateApplicationsConfirmed(@RequestParam("id") int appId){
		
		System.out.println("In Controller updateApplicationsConfirmed:"+appId);
		
		ModelAndView model =null;
		String status="confirmed";
		
		try {
			boolean update =service.updateApplicationDB(appId,status);
			if(update==true){
				
				List<ProgramsScheduled> schedule =service.getAllProgramSheduled();
				model=new ModelAndView("showSheduleDetail");
				model.addObject("data", schedule);
			}
			else{
				
				model=new ModelAndView("errorMember");
				model.addObject("msg", "Unable to Confirm Application");
			}
		} catch (UniversityAdmissionException e) {
			model=new ModelAndView("errorMember");
			model.addObject("msg", "Unable to Confirm Application");
			e.printStackTrace();
		}
		return model;
		
	}
	
	@RequestMapping("/rejectCandidate.do")
		public ModelAndView updateApplicationsRejected(@RequestParam("id") int appId){
		
		System.out.println("In Controller updateApplicationsRejected:"+appId);
		ModelAndView model =null;
		String status="rejected";
		
		try {
			boolean update =service.updateApplicationDB(appId,status);
			if(update==true){
				
				List<ProgramsScheduled> schedule =service.getAllProgramSheduled();
				model=new ModelAndView("showSheduleDetail");
				model.addObject("data", schedule);
			}
			else{
				
				model=new ModelAndView("errorMember");
				model.addObject("msg", "Unable to reject Application");
			}
		} catch (UniversityAdmissionException e) {
			model=new ModelAndView("errorMember");
			model.addObject("msg", "Unable to reject Application");
			e.printStackTrace();
		}
		return model;
	}
		
	

	/////////////////////////////////////////////////
/*	//show List of Employee
	@RequestMapping("showAllEmps")
	public ModelAndView showAllEmps() {
		ModelAndView model = null;
		try {
			List<Emp> list = service.getAllEmps();
			model = new ModelAndView("showAllEmps");
			model.addObject("list", list);
		} catch (EmpEcxeption e) {
			model = new ModelAndView("error");
			model.addObject("msg", e);
		}
		return model;
	}

	//Navigate to New Employee Entry Form
	@RequestMapping("addNewEmp")
	public ModelAndView addNew(ModelAndView model) {

		Emp emp = new Emp();
		model.addObject("emp", emp);
		model.addObject("designation", designation);
		model.setViewName("addNewEmp");
		return model;

	}

	//Add Employee to Database Or Show error
	@RequestMapping("addEmp")
	public ModelAndView addEmp(@ModelAttribute @Valid Emp emp,
			BindingResult result) {
		ModelAndView model = new ModelAndView();
		if (result.hasErrors()) {
			model.addObject("emp", emp);
			model.addObject("designation", designation);
			model.setViewName("addNewEmp");
			return model;
		}

		try {
			Emp myemp = service.insertNewEmp(emp);
			model.addObject("emp", myemp);
			model.setViewName("successEmp");
			return model;
		} catch (EmpEcxeption e) {
			model.setViewName("error");
			model.addObject("msg", e);
			return model;
		}

	}
*/
	
	
}